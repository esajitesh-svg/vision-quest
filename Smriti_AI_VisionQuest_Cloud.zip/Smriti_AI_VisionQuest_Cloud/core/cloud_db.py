"""SQLite demo vault shared by the cloud app's authenticated viewers."""
from __future__ import annotations
import csv
import io
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(os.getenv("SMRITI_DB_PATH", str(ROOT / "data" / "visionquest_cloud.db")))

@contextmanager
def connect():
    """Open a connection and guarantee commit/rollback plus close."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=10000")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with connect() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS people (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL COLLATE NOCASE UNIQUE, relationship TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)")
        conn.execute("CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, created_at TEXT NOT NULL, note TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'Manual', FOREIGN KEY(person_id) REFERENCES people(id) ON DELETE CASCADE)")

def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

def save_person(name: str, relationship: str, notes: str = ""):
    name, relationship, notes = (name or "").strip(), (relationship or "").strip(), (notes or "").strip()
    if not name or not relationship:
        raise ValueError("Name and relationship/label are required.")
    if len(name) > 100 or len(relationship) > 100 or len(notes) > 1000:
        raise ValueError("Name/label must be at most 100 characters and notes at most 1,000 characters.")
    try:
        with connect() as conn:
            conn.execute("INSERT INTO people(name,relationship,notes,created_at) VALUES(?,?,?,?)", (name, relationship, notes, now()))
    except sqlite3.IntegrityError as exc:
        raise ValueError("That display name already exists in this shared demo vault.") from exc

def list_people():
    with connect() as conn:
        return [dict(row) for row in conn.execute("SELECT * FROM people ORDER BY name COLLATE NOCASE").fetchall()]

def save_memory(person_id: int, note: str, source: str = "Manual"):
    note, source = (note or "").strip(), (source or "Manual").strip()[:300]
    if not note:
        raise ValueError("Memory note cannot be empty.")
    if len(note) > 4000:
        raise ValueError("Memory note must be 4,000 characters or fewer.")
    with connect() as conn:
        exists = conn.execute("SELECT 1 FROM people WHERE id=?", (int(person_id),)).fetchone()
        if not exists:
            raise ValueError("Selected person no longer exists. Refresh the page and try again.")
        conn.execute("INSERT INTO memories(person_id,created_at,note,source) VALUES(?,?,?,?)", (int(person_id), now(), note, source))

def list_memories(limit: int = 500):
    with connect() as conn:
        rows = conn.execute("SELECT m.*,p.name AS person_name,p.relationship FROM memories m JOIN people p ON p.id=m.person_id ORDER BY m.id DESC LIMIT ?", (max(1, min(int(limit), 1000)),)).fetchall()
        return [dict(row) for row in rows]

def search_memories(query: str, limit: int = 100):
    needle = (query or "").strip().casefold()
    if not needle:
        return []
    return [row for row in list_memories(limit=1000) if needle in " ".join(str(row.get(k, "")) for k in ("person_name", "relationship", "note", "source")).casefold()][:max(1,min(int(limit),500))]

def export_memories_csv() -> bytes:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["person_name", "relationship", "created_at", "note", "source"])
    for row in list_memories(limit=1000):
        values = [row["person_name"], row["relationship"], row["created_at"], row["note"], row["source"]]
        safe = [("'" + v) if isinstance(v, str) and v.startswith(("=", "+", "-", "@", "\t", "\r")) else v for v in values]
        writer.writerow(safe)
    return output.getvalue().encode("utf-8-sig")
