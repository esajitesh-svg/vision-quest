import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from core import cloud_db

class CloudDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / 'test.db'
        self.patch = patch.object(cloud_db, 'DB_PATH', self.db_path)
        self.patch.start()
        cloud_db.init_db()

    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()

    def test_person_and_memory_roundtrip(self):
        cloud_db.save_person('Demo Person', 'Family member', 'Fictional test profile')
        person = cloud_db.list_people()[0]
        cloud_db.save_memory(person['id'], 'Likes reading books', 'Reviewed test observation')
        rows = cloud_db.list_memories()
        self.assertEqual(rows[0]['person_name'], 'Demo Person')
        self.assertIn('reading books', rows[0]['note'])

    def test_duplicate_person_rejected(self):
        cloud_db.save_person('Demo Person', 'Family member')
        with self.assertRaises(ValueError):
            cloud_db.save_person('demo person', 'Friend')

    def test_search_and_csv_export(self):
        cloud_db.save_person('Sample Person', 'Demo')
        person = cloud_db.list_people()[0]
        cloud_db.save_memory(person['id'], 'Enjoys science books')
        self.assertEqual(len(cloud_db.search_memories('science')), 1)
        self.assertIn(b'person_name', cloud_db.export_memories_csv())

if __name__ == '__main__':
    unittest.main()
