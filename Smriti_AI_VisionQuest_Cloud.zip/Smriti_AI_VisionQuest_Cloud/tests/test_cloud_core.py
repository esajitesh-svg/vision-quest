import io
import tempfile
import unittest
from pathlib import Path
from PIL import Image

from core.cloud_vision import MODE_LABELS, build_prompt, prepare_image

class CloudVisionTests(unittest.TestCase):
    def png(self, size=(1000, 600)):
        im = Image.new("RGB", size, color=(120, 90, 80))
        buf = io.BytesIO(); im.save(buf, format="PNG"); return buf.getvalue()

    def test_prepare_image_resizes(self):
        image, original = prepare_image(self.png(), 512)
        self.assertEqual(original, (1000, 600))
        self.assertLessEqual(max(image.size), 512)

    def test_prepare_image_rejects_empty(self):
        with self.assertRaises(ValueError): prepare_image(b"")

    def test_prompt_contains_guardrails(self):
        prompt = build_prompt("scene")
        self.assertIn("Do not identify a person", prompt)
        self.assertIn("Do not greet", prompt)

    def test_all_modes_have_labels(self):
        self.assertEqual(set(MODE_LABELS), {"scene", "objects", "read_text", "accessibility", "visual_question"})

if __name__ == "__main__": unittest.main()
